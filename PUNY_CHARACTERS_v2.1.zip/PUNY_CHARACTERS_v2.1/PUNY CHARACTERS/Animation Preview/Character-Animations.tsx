<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.8" tiledversion="1.8.4" name="Character-Animations" tilewidth="32" tileheight="32" tilecount="232" columns="29">
 <image source="Character-Placeholder1.png" width="928" height="256"/>
 <tile id="0">
  <animation>
   <frame tileid="0" duration="300"/>
   <frame tileid="1" duration="300"/>
  </animation>
 </tile>
 <tile id="1">
  <animation>
   <frame tileid="1" duration="200"/>
   <frame tileid="2" duration="200"/>
   <frame tileid="3" duration="200"/>
   <frame tileid="4" duration="200"/>
  </animation>
 </tile>
 <tile id="3">
  <animation>
   <frame tileid="3" duration="100"/>
   <frame tileid="32" duration="100"/>
   <frame tileid="61" duration="100"/>
   <frame tileid="90" duration="100"/>
   <frame tileid="119" duration="100"/>
   <frame tileid="148" duration="100"/>
   <frame tileid="177" duration="100"/>
   <frame tileid="206" duration="100"/>
  </animation>
 </tile>
 <tile id="5">
  <animation>
   <frame tileid="5" duration="100"/>
   <frame tileid="6" duration="100"/>
   <frame tileid="7" duration="100"/>
   <frame tileid="8" duration="100"/>
  </animation>
 </tile>
 <tile id="6">
  <animation>
   <frame tileid="5" duration="100"/>
   <frame tileid="34" duration="100"/>
   <frame tileid="63" duration="100"/>
   <frame tileid="92" duration="100"/>
   <frame tileid="121" duration="100"/>
   <frame tileid="150" duration="100"/>
   <frame tileid="179" duration="100"/>
   <frame tileid="208" duration="100"/>
  </animation>
 </tile>
 <tile id="9">
  <animation>
   <frame tileid="9" duration="100"/>
   <frame tileid="10" duration="100"/>
   <frame tileid="11" duration="100"/>
   <frame tileid="12" duration="100"/>
  </animation>
 </tile>
 <tile id="10">
  <animation>
   <frame tileid="9" duration="100"/>
   <frame tileid="38" duration="100"/>
   <frame tileid="67" duration="100"/>
   <frame tileid="96" duration="100"/>
   <frame tileid="125" duration="100"/>
   <frame tileid="154" duration="100"/>
   <frame tileid="183" duration="100"/>
   <frame tileid="212" duration="100"/>
  </animation>
 </tile>
 <tile id="13">
  <animation>
   <frame tileid="13" duration="100"/>
   <frame tileid="14" duration="100"/>
   <frame tileid="15" duration="100"/>
   <frame tileid="15" duration="100"/>
  </animation>
 </tile>
 <tile id="14">
  <animation>
   <frame tileid="14" duration="100"/>
   <frame tileid="43" duration="100"/>
   <frame tileid="72" duration="100"/>
   <frame tileid="101" duration="100"/>
   <frame tileid="130" duration="100"/>
   <frame tileid="159" duration="100"/>
   <frame tileid="188" duration="100"/>
   <frame tileid="217" duration="100"/>
  </animation>
 </tile>
 <tile id="16">
  <animation>
   <frame tileid="16" duration="100"/>
   <frame tileid="17" duration="100"/>
   <frame tileid="18" duration="100"/>
   <frame tileid="18" duration="100"/>
  </animation>
 </tile>
 <tile id="17">
  <animation>
   <frame tileid="17" duration="100"/>
   <frame tileid="46" duration="100"/>
   <frame tileid="75" duration="100"/>
   <frame tileid="104" duration="100"/>
   <frame tileid="133" duration="100"/>
   <frame tileid="162" duration="100"/>
   <frame tileid="191" duration="100"/>
   <frame tileid="220" duration="100"/>
  </animation>
 </tile>
 <tile id="19">
  <animation>
   <frame tileid="19" duration="100"/>
   <frame tileid="20" duration="100"/>
   <frame tileid="21" duration="100"/>
  </animation>
 </tile>
 <tile id="21">
  <animation>
   <frame tileid="21" duration="100"/>
   <frame tileid="50" duration="100"/>
   <frame tileid="79" duration="100"/>
   <frame tileid="108" duration="100"/>
   <frame tileid="137" duration="100"/>
   <frame tileid="166" duration="100"/>
   <frame tileid="195" duration="100"/>
  </animation>
 </tile>
 <tile id="22">
  <animation>
   <frame tileid="22" duration="100"/>
   <frame tileid="23" duration="100"/>
   <frame tileid="24" duration="100"/>
   <frame tileid="23" duration="800"/>
  </animation>
 </tile>
 <tile id="25">
  <animation>
   <frame tileid="25" duration="200"/>
   <frame tileid="26" duration="200"/>
   <frame tileid="25" duration="200"/>
   <frame tileid="27" duration="200"/>
  </animation>
 </tile>
 <tile id="28">
  <animation>
   <frame tileid="0" duration="100"/>
   <frame tileid="28" duration="200"/>
   <frame tileid="25" duration="100"/>
   <frame tileid="19" duration="100"/>
  </animation>
 </tile>
 <tile id="29">
  <animation>
   <frame tileid="29" duration="300"/>
   <frame tileid="30" duration="300"/>
  </animation>
 </tile>
 <tile id="30">
  <animation>
   <frame tileid="30" duration="200"/>
   <frame tileid="31" duration="200"/>
   <frame tileid="32" duration="200"/>
   <frame tileid="33" duration="200"/>
  </animation>
 </tile>
 <tile id="34">
  <animation>
   <frame tileid="34" duration="100"/>
   <frame tileid="35" duration="100"/>
   <frame tileid="36" duration="100"/>
   <frame tileid="37" duration="100"/>
  </animation>
 </tile>
 <tile id="38">
  <animation>
   <frame tileid="38" duration="100"/>
   <frame tileid="39" duration="100"/>
   <frame tileid="40" duration="100"/>
   <frame tileid="41" duration="100"/>
  </animation>
 </tile>
 <tile id="42">
  <animation>
   <frame tileid="42" duration="100"/>
   <frame tileid="43" duration="100"/>
   <frame tileid="44" duration="100"/>
   <frame tileid="44" duration="100"/>
  </animation>
 </tile>
 <tile id="45">
  <animation>
   <frame tileid="45" duration="100"/>
   <frame tileid="46" duration="100"/>
   <frame tileid="47" duration="100"/>
   <frame tileid="47" duration="100"/>
  </animation>
 </tile>
 <tile id="48">
  <animation>
   <frame tileid="48" duration="100"/>
   <frame tileid="49" duration="100"/>
   <frame tileid="50" duration="100"/>
  </animation>
 </tile>
 <tile id="51">
  <animation>
   <frame tileid="51" duration="100"/>
   <frame tileid="52" duration="100"/>
   <frame tileid="53" duration="100"/>
   <frame tileid="52" duration="800"/>
  </animation>
 </tile>
 <tile id="54">
  <animation>
   <frame tileid="54" duration="200"/>
   <frame tileid="55" duration="200"/>
   <frame tileid="54" duration="200"/>
   <frame tileid="56" duration="200"/>
  </animation>
 </tile>
 <tile id="57">
  <animation>
   <frame tileid="29" duration="100"/>
   <frame tileid="57" duration="200"/>
   <frame tileid="54" duration="100"/>
   <frame tileid="48" duration="100"/>
  </animation>
 </tile>
 <tile id="58">
  <animation>
   <frame tileid="58" duration="300"/>
   <frame tileid="59" duration="300"/>
  </animation>
 </tile>
 <tile id="59">
  <animation>
   <frame tileid="59" duration="200"/>
   <frame tileid="60" duration="200"/>
   <frame tileid="61" duration="200"/>
   <frame tileid="62" duration="200"/>
  </animation>
 </tile>
 <tile id="63">
  <animation>
   <frame tileid="63" duration="100"/>
   <frame tileid="64" duration="100"/>
   <frame tileid="65" duration="100"/>
   <frame tileid="66" duration="100"/>
  </animation>
 </tile>
 <tile id="67">
  <animation>
   <frame tileid="67" duration="100"/>
   <frame tileid="68" duration="100"/>
   <frame tileid="69" duration="100"/>
   <frame tileid="70" duration="100"/>
  </animation>
 </tile>
 <tile id="71">
  <animation>
   <frame tileid="71" duration="100"/>
   <frame tileid="72" duration="100"/>
   <frame tileid="73" duration="100"/>
   <frame tileid="73" duration="100"/>
  </animation>
 </tile>
 <tile id="74">
  <animation>
   <frame tileid="74" duration="100"/>
   <frame tileid="75" duration="100"/>
   <frame tileid="76" duration="100"/>
   <frame tileid="76" duration="100"/>
  </animation>
 </tile>
 <tile id="77">
  <animation>
   <frame tileid="77" duration="100"/>
   <frame tileid="78" duration="100"/>
   <frame tileid="79" duration="100"/>
  </animation>
 </tile>
 <tile id="80">
  <animation>
   <frame tileid="80" duration="100"/>
   <frame tileid="81" duration="100"/>
   <frame tileid="82" duration="100"/>
   <frame tileid="81" duration="800"/>
  </animation>
 </tile>
 <tile id="83">
  <animation>
   <frame tileid="83" duration="200"/>
   <frame tileid="84" duration="200"/>
   <frame tileid="83" duration="200"/>
   <frame tileid="85" duration="200"/>
  </animation>
 </tile>
 <tile id="86">
  <animation>
   <frame tileid="58" duration="100"/>
   <frame tileid="86" duration="200"/>
   <frame tileid="83" duration="100"/>
   <frame tileid="77" duration="100"/>
  </animation>
 </tile>
 <tile id="87">
  <animation>
   <frame tileid="87" duration="300"/>
   <frame tileid="88" duration="300"/>
  </animation>
 </tile>
 <tile id="88">
  <animation>
   <frame tileid="88" duration="200"/>
   <frame tileid="89" duration="200"/>
   <frame tileid="90" duration="200"/>
   <frame tileid="91" duration="200"/>
  </animation>
 </tile>
 <tile id="92">
  <animation>
   <frame tileid="92" duration="100"/>
   <frame tileid="93" duration="100"/>
   <frame tileid="94" duration="100"/>
   <frame tileid="95" duration="100"/>
  </animation>
 </tile>
 <tile id="96">
  <animation>
   <frame tileid="96" duration="100"/>
   <frame tileid="97" duration="100"/>
   <frame tileid="98" duration="100"/>
   <frame tileid="99" duration="100"/>
  </animation>
 </tile>
 <tile id="100">
  <animation>
   <frame tileid="100" duration="100"/>
   <frame tileid="101" duration="100"/>
   <frame tileid="102" duration="100"/>
   <frame tileid="102" duration="100"/>
  </animation>
 </tile>
 <tile id="103">
  <animation>
   <frame tileid="103" duration="100"/>
   <frame tileid="104" duration="100"/>
   <frame tileid="105" duration="100"/>
   <frame tileid="105" duration="100"/>
  </animation>
 </tile>
 <tile id="106">
  <animation>
   <frame tileid="106" duration="100"/>
   <frame tileid="107" duration="100"/>
   <frame tileid="108" duration="100"/>
  </animation>
 </tile>
 <tile id="109">
  <animation>
   <frame tileid="109" duration="100"/>
   <frame tileid="110" duration="100"/>
   <frame tileid="111" duration="100"/>
   <frame tileid="110" duration="800"/>
  </animation>
 </tile>
 <tile id="112">
  <animation>
   <frame tileid="112" duration="200"/>
   <frame tileid="113" duration="200"/>
   <frame tileid="112" duration="200"/>
   <frame tileid="114" duration="200"/>
  </animation>
 </tile>
 <tile id="115">
  <animation>
   <frame tileid="87" duration="100"/>
   <frame tileid="115" duration="200"/>
   <frame tileid="112" duration="100"/>
   <frame tileid="106" duration="100"/>
  </animation>
 </tile>
 <tile id="116">
  <animation>
   <frame tileid="116" duration="300"/>
   <frame tileid="117" duration="300"/>
  </animation>
 </tile>
 <tile id="117">
  <animation>
   <frame tileid="117" duration="200"/>
   <frame tileid="118" duration="200"/>
   <frame tileid="119" duration="200"/>
   <frame tileid="120" duration="200"/>
  </animation>
 </tile>
 <tile id="121">
  <animation>
   <frame tileid="121" duration="100"/>
   <frame tileid="122" duration="100"/>
   <frame tileid="123" duration="100"/>
   <frame tileid="124" duration="100"/>
  </animation>
 </tile>
 <tile id="125">
  <animation>
   <frame tileid="125" duration="100"/>
   <frame tileid="126" duration="100"/>
   <frame tileid="127" duration="100"/>
   <frame tileid="128" duration="100"/>
  </animation>
 </tile>
 <tile id="129">
  <animation>
   <frame tileid="129" duration="100"/>
   <frame tileid="130" duration="100"/>
   <frame tileid="131" duration="100"/>
   <frame tileid="131" duration="100"/>
  </animation>
 </tile>
 <tile id="132">
  <animation>
   <frame tileid="132" duration="100"/>
   <frame tileid="133" duration="100"/>
   <frame tileid="134" duration="100"/>
   <frame tileid="134" duration="100"/>
  </animation>
 </tile>
 <tile id="135">
  <animation>
   <frame tileid="135" duration="100"/>
   <frame tileid="136" duration="100"/>
   <frame tileid="137" duration="100"/>
  </animation>
 </tile>
 <tile id="138">
  <animation>
   <frame tileid="117" duration="100"/>
   <frame tileid="139" duration="100"/>
   <frame tileid="140" duration="100"/>
   <frame tileid="139" duration="800"/>
  </animation>
 </tile>
 <tile id="141">
  <animation>
   <frame tileid="141" duration="200"/>
   <frame tileid="142" duration="200"/>
   <frame tileid="141" duration="200"/>
   <frame tileid="143" duration="200"/>
  </animation>
 </tile>
 <tile id="144">
  <animation>
   <frame tileid="116" duration="100"/>
   <frame tileid="144" duration="200"/>
   <frame tileid="141" duration="100"/>
   <frame tileid="135" duration="100"/>
  </animation>
 </tile>
 <tile id="145">
  <animation>
   <frame tileid="145" duration="300"/>
   <frame tileid="146" duration="300"/>
  </animation>
 </tile>
 <tile id="146">
  <animation>
   <frame tileid="146" duration="200"/>
   <frame tileid="147" duration="200"/>
   <frame tileid="148" duration="200"/>
   <frame tileid="149" duration="200"/>
  </animation>
 </tile>
 <tile id="150">
  <animation>
   <frame tileid="150" duration="100"/>
   <frame tileid="151" duration="100"/>
   <frame tileid="152" duration="100"/>
   <frame tileid="153" duration="100"/>
  </animation>
 </tile>
 <tile id="154">
  <animation>
   <frame tileid="154" duration="100"/>
   <frame tileid="155" duration="100"/>
   <frame tileid="156" duration="100"/>
   <frame tileid="157" duration="100"/>
  </animation>
 </tile>
 <tile id="158">
  <animation>
   <frame tileid="158" duration="100"/>
   <frame tileid="159" duration="100"/>
   <frame tileid="160" duration="100"/>
   <frame tileid="160" duration="100"/>
  </animation>
 </tile>
 <tile id="161">
  <animation>
   <frame tileid="161" duration="100"/>
   <frame tileid="162" duration="100"/>
   <frame tileid="163" duration="100"/>
   <frame tileid="163" duration="100"/>
  </animation>
 </tile>
 <tile id="164">
  <animation>
   <frame tileid="164" duration="100"/>
   <frame tileid="165" duration="100"/>
   <frame tileid="166" duration="100"/>
  </animation>
 </tile>
 <tile id="167">
  <animation>
   <frame tileid="167" duration="100"/>
   <frame tileid="168" duration="100"/>
   <frame tileid="169" duration="100"/>
   <frame tileid="168" duration="800"/>
  </animation>
 </tile>
 <tile id="170">
  <animation>
   <frame tileid="170" duration="200"/>
   <frame tileid="171" duration="200"/>
   <frame tileid="170" duration="200"/>
   <frame tileid="172" duration="200"/>
  </animation>
 </tile>
 <tile id="173">
  <animation>
   <frame tileid="145" duration="100"/>
   <frame tileid="173" duration="200"/>
   <frame tileid="170" duration="100"/>
   <frame tileid="164" duration="100"/>
  </animation>
 </tile>
 <tile id="174">
  <animation>
   <frame tileid="174" duration="300"/>
   <frame tileid="175" duration="300"/>
  </animation>
 </tile>
 <tile id="175">
  <animation>
   <frame tileid="175" duration="200"/>
   <frame tileid="176" duration="200"/>
   <frame tileid="177" duration="200"/>
   <frame tileid="178" duration="200"/>
  </animation>
 </tile>
 <tile id="179">
  <animation>
   <frame tileid="179" duration="100"/>
   <frame tileid="180" duration="100"/>
   <frame tileid="181" duration="100"/>
   <frame tileid="182" duration="100"/>
  </animation>
 </tile>
 <tile id="183">
  <animation>
   <frame tileid="183" duration="100"/>
   <frame tileid="184" duration="100"/>
   <frame tileid="185" duration="100"/>
   <frame tileid="186" duration="100"/>
  </animation>
 </tile>
 <tile id="187">
  <animation>
   <frame tileid="187" duration="100"/>
   <frame tileid="188" duration="100"/>
   <frame tileid="189" duration="100"/>
   <frame tileid="189" duration="100"/>
  </animation>
 </tile>
 <tile id="190">
  <animation>
   <frame tileid="190" duration="100"/>
   <frame tileid="191" duration="100"/>
   <frame tileid="192" duration="100"/>
   <frame tileid="192" duration="100"/>
  </animation>
 </tile>
 <tile id="193">
  <animation>
   <frame tileid="193" duration="100"/>
   <frame tileid="194" duration="100"/>
   <frame tileid="195" duration="100"/>
  </animation>
 </tile>
 <tile id="196">
  <animation>
   <frame tileid="196" duration="100"/>
   <frame tileid="197" duration="100"/>
   <frame tileid="198" duration="100"/>
   <frame tileid="197" duration="800"/>
  </animation>
 </tile>
 <tile id="199">
  <animation>
   <frame tileid="199" duration="200"/>
   <frame tileid="200" duration="200"/>
   <frame tileid="199" duration="200"/>
   <frame tileid="201" duration="200"/>
  </animation>
 </tile>
 <tile id="202">
  <animation>
   <frame tileid="174" duration="100"/>
   <frame tileid="202" duration="200"/>
   <frame tileid="199" duration="100"/>
   <frame tileid="193" duration="100"/>
  </animation>
 </tile>
 <tile id="203">
  <animation>
   <frame tileid="203" duration="300"/>
   <frame tileid="204" duration="300"/>
  </animation>
 </tile>
 <tile id="204">
  <animation>
   <frame tileid="204" duration="200"/>
   <frame tileid="205" duration="200"/>
   <frame tileid="206" duration="200"/>
   <frame tileid="207" duration="200"/>
  </animation>
 </tile>
 <tile id="208">
  <animation>
   <frame tileid="208" duration="100"/>
   <frame tileid="209" duration="100"/>
   <frame tileid="210" duration="100"/>
   <frame tileid="211" duration="100"/>
  </animation>
 </tile>
 <tile id="212">
  <animation>
   <frame tileid="212" duration="100"/>
   <frame tileid="213" duration="100"/>
   <frame tileid="214" duration="100"/>
   <frame tileid="215" duration="100"/>
  </animation>
 </tile>
 <tile id="216">
  <animation>
   <frame tileid="216" duration="100"/>
   <frame tileid="217" duration="100"/>
   <frame tileid="218" duration="100"/>
   <frame tileid="218" duration="100"/>
  </animation>
 </tile>
 <tile id="219">
  <animation>
   <frame tileid="219" duration="100"/>
   <frame tileid="220" duration="100"/>
   <frame tileid="221" duration="100"/>
   <frame tileid="221" duration="100"/>
  </animation>
 </tile>
 <tile id="222">
  <animation>
   <frame tileid="222" duration="100"/>
   <frame tileid="223" duration="100"/>
   <frame tileid="224" duration="100"/>
  </animation>
 </tile>
 <tile id="225">
  <animation>
   <frame tileid="225" duration="100"/>
   <frame tileid="226" duration="100"/>
   <frame tileid="227" duration="100"/>
   <frame tileid="226" duration="800"/>
  </animation>
 </tile>
 <tile id="227">
  <animation>
   <frame tileid="22" duration="100"/>
  </animation>
 </tile>
 <tile id="228">
  <animation>
   <frame tileid="228" duration="200"/>
   <frame tileid="229" duration="200"/>
   <frame tileid="228" duration="200"/>
   <frame tileid="230" duration="200"/>
  </animation>
 </tile>
 <tile id="230">
  <animation>
   <frame tileid="0" duration="50"/>
   <frame tileid="29" duration="50"/>
   <frame tileid="58" duration="50"/>
   <frame tileid="87" duration="50"/>
   <frame tileid="116" duration="50"/>
   <frame tileid="145" duration="50"/>
   <frame tileid="174" duration="50"/>
   <frame tileid="203" duration="50"/>
   <frame tileid="25" duration="100"/>
   <frame tileid="28" duration="100"/>
   <frame tileid="25" duration="200"/>
   <frame tileid="19" duration="100"/>
  </animation>
 </tile>
 <tile id="231">
  <animation>
   <frame tileid="203" duration="100"/>
   <frame tileid="231" duration="200"/>
   <frame tileid="228" duration="100"/>
   <frame tileid="222" duration="100"/>
  </animation>
 </tile>
</tileset>
