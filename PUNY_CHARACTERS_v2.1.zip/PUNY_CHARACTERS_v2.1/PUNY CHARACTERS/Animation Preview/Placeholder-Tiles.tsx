<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.8" tiledversion="1.8.4" name="Placeholder-Tiles" tilewidth="16" tileheight="16" tilecount="100" columns="10">
 <image source="Placeholder-Tiles.png" width="160" height="160"/>
</tileset>
