<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.8" tiledversion="1.8.4" name="Character-Placeholder2" tilewidth="32" tileheight="32" tilecount="232" columns="29">
 <image source="Character-Placeholder2.png" width="928" height="256"/>
</tileset>
