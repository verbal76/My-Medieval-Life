<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.8" tiledversion="1.8.4" name="Orthogonal-tiles" tilewidth="16" tileheight="16" tilecount="100" columns="10">
 <image source="Orthogonal-tiles.png" width="160" height="160"/>
 <wangsets>
  <wangset name="Grass-Sand" type="corner" tile="-1">
   <wangcolor name="LightGrass" color="#00aa00" tile="-1" probability="1"/>
   <wangcolor name="DarkGrass" color="#006400" tile="-1" probability="1"/>
   <wangcolor name="Sand" color="#ffff00" tile="-1" probability="1"/>
   <wangcolor name="LightWater" color="#00ffff" tile="-1" probability="1"/>
   <wangcolor name="DarkWater" color="#5555ff" tile="-1" probability="1"/>
   <wangcolor name="Rock" color="#aaaa7f" tile="-1" probability="1"/>
   <wangcolor name="Nothingness" color="#ffffff" tile="-1" probability="1"/>
   <wangtile tileid="0" wangid="0,1,0,1,0,1,0,1"/>
   <wangtile tileid="1" wangid="0,2,0,2,0,2,0,2"/>
   <wangtile tileid="2" wangid="0,6,0,6,0,6,0,6"/>
   <wangtile tileid="3" wangid="0,3,0,3,0,3,0,3"/>
   <wangtile tileid="4" wangid="0,4,0,4,0,4,0,4"/>
   <wangtile tileid="5" wangid="0,5,0,5,0,5,0,5"/>
   <wangtile tileid="9" wangid="0,7,0,7,0,7,0,7"/>
   <wangtile tileid="10" wangid="0,7,0,1,0,7,0,7"/>
   <wangtile tileid="11" wangid="0,7,0,1,0,1,0,7"/>
   <wangtile tileid="12" wangid="0,7,0,7,0,1,0,7"/>
   <wangtile tileid="13" wangid="0,1,0,1,0,1,0,7"/>
   <wangtile tileid="14" wangid="0,7,0,1,0,1,0,1"/>
   <wangtile tileid="15" wangid="0,7,0,6,0,7,0,7"/>
   <wangtile tileid="16" wangid="0,7,0,6,0,6,0,7"/>
   <wangtile tileid="17" wangid="0,7,0,7,0,6,0,7"/>
   <wangtile tileid="18" wangid="0,6,0,6,0,6,0,7"/>
   <wangtile tileid="19" wangid="0,7,0,6,0,6,0,6"/>
   <wangtile tileid="20" wangid="0,1,0,1,0,7,0,7"/>
   <wangtile tileid="22" wangid="0,7,0,7,0,1,0,1"/>
   <wangtile tileid="23" wangid="0,1,0,1,0,7,0,1"/>
   <wangtile tileid="24" wangid="0,1,0,7,0,1,0,1"/>
   <wangtile tileid="25" wangid="0,6,0,6,0,7,0,7"/>
   <wangtile tileid="27" wangid="0,7,0,7,0,6,0,6"/>
   <wangtile tileid="28" wangid="0,6,0,6,0,7,0,6"/>
   <wangtile tileid="29" wangid="0,6,0,7,0,6,0,6"/>
   <wangtile tileid="30" wangid="0,1,0,7,0,7,0,7"/>
   <wangtile tileid="31" wangid="0,1,0,7,0,7,0,1"/>
   <wangtile tileid="32" wangid="0,7,0,7,0,7,0,1"/>
   <wangtile tileid="35" wangid="0,6,0,7,0,7,0,7"/>
   <wangtile tileid="36" wangid="0,6,0,7,0,7,0,6"/>
   <wangtile tileid="37" wangid="0,7,0,7,0,7,0,6"/>
   <wangtile tileid="40" wangid="0,1,0,3,0,1,0,1"/>
   <wangtile tileid="41" wangid="0,1,0,3,0,3,0,1"/>
   <wangtile tileid="42" wangid="0,1,0,1,0,3,0,1"/>
   <wangtile tileid="43" wangid="0,3,0,3,0,3,0,1"/>
   <wangtile tileid="44" wangid="0,1,0,3,0,3,0,3"/>
   <wangtile tileid="45" wangid="0,2,0,1,0,2,0,2"/>
   <wangtile tileid="46" wangid="0,2,0,1,0,1,0,2"/>
   <wangtile tileid="47" wangid="0,2,0,2,0,1,0,2"/>
   <wangtile tileid="48" wangid="0,1,0,1,0,1,0,2"/>
   <wangtile tileid="49" wangid="0,2,0,1,0,1,0,1"/>
   <wangtile tileid="50" wangid="0,3,0,3,0,1,0,1"/>
   <wangtile tileid="52" wangid="0,1,0,1,0,3,0,3"/>
   <wangtile tileid="53" wangid="0,3,0,3,0,1,0,3"/>
   <wangtile tileid="54" wangid="0,3,0,1,0,3,0,3"/>
   <wangtile tileid="55" wangid="0,1,0,1,0,2,0,2"/>
   <wangtile tileid="57" wangid="0,2,0,2,0,1,0,1"/>
   <wangtile tileid="58" wangid="0,1,0,1,0,2,0,1"/>
   <wangtile tileid="59" wangid="0,1,0,2,0,1,0,1"/>
   <wangtile tileid="60" wangid="0,3,0,1,0,1,0,1"/>
   <wangtile tileid="61" wangid="0,3,0,1,0,1,0,3"/>
   <wangtile tileid="62" wangid="0,1,0,1,0,1,0,3"/>
   <wangtile tileid="65" wangid="0,1,0,2,0,2,0,2"/>
   <wangtile tileid="66" wangid="0,1,0,2,0,2,0,1"/>
   <wangtile tileid="67" wangid="0,2,0,2,0,2,0,1"/>
   <wangtile tileid="70" wangid="0,4,0,5,0,4,0,4"/>
   <wangtile tileid="71" wangid="0,4,0,5,0,5,0,4"/>
   <wangtile tileid="72" wangid="0,4,0,4,0,5,0,4"/>
   <wangtile tileid="73" wangid="0,5,0,5,0,5,0,4"/>
   <wangtile tileid="74" wangid="0,4,0,5,0,5,0,5"/>
   <wangtile tileid="75" wangid="0,3,0,4,0,3,0,3"/>
   <wangtile tileid="76" wangid="0,3,0,4,0,4,0,3"/>
   <wangtile tileid="77" wangid="0,3,0,3,0,4,0,3"/>
   <wangtile tileid="78" wangid="0,4,0,4,0,4,0,3"/>
   <wangtile tileid="79" wangid="0,3,0,4,0,4,0,4"/>
   <wangtile tileid="80" wangid="0,5,0,5,0,4,0,4"/>
   <wangtile tileid="82" wangid="0,4,0,4,0,5,0,5"/>
   <wangtile tileid="83" wangid="0,5,0,5,0,4,0,5"/>
   <wangtile tileid="84" wangid="0,5,0,4,0,5,0,5"/>
   <wangtile tileid="85" wangid="0,4,0,4,0,3,0,3"/>
   <wangtile tileid="87" wangid="0,3,0,3,0,4,0,4"/>
   <wangtile tileid="88" wangid="0,4,0,4,0,3,0,4"/>
   <wangtile tileid="89" wangid="0,4,0,3,0,4,0,4"/>
   <wangtile tileid="90" wangid="0,5,0,4,0,4,0,4"/>
   <wangtile tileid="91" wangid="0,5,0,4,0,4,0,5"/>
   <wangtile tileid="92" wangid="0,4,0,4,0,4,0,5"/>
   <wangtile tileid="95" wangid="0,4,0,3,0,3,0,3"/>
   <wangtile tileid="96" wangid="0,4,0,3,0,3,0,4"/>
   <wangtile tileid="97" wangid="0,3,0,3,0,3,0,4"/>
  </wangset>
 </wangsets>
</tileset>
