<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.8" tiledversion="1.8.4" name="Characters" tilewidth="32" tileheight="32" tilecount="14336" columns="112">
 <image source="Characters.png" width="3584" height="4096"/>
</tileset>
