<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="puny-world-tiles" tilewidth="16" tileheight="16" tilecount="29040" columns="220">
 <image source="punyworld-tiles.png" width="3520" height="2112"/>
 <tile id="5958">
  <animation>
   <frame tileid="5958" duration="100"/>
   <frame tileid="5959" duration="100"/>
   <frame tileid="5960" duration="100"/>
   <frame tileid="5961" duration="100"/>
  </animation>
 </tile>
</tileset>
